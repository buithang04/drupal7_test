<?php

/**
 * @file
 * Test PHP file for Libraries loading.
 */

// @see _libraries_require_once()
$path = 'abc';

/**
 * Dummy function to see if this file was loaded.
 */
function _libraries_test_module_example_1() {
}
